
function showPage(pageId) {
  document.getElementById("main-grid").style.display = 'none';
  document.getElementById(pageId).style.display = 'block';
  if (pageId === 'data') renderChart();
}
function goBack() {
  document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
  document.getElementById("main-grid").style.display = 'grid';
}
function renderChart() {
  const ctx = document.getElementById('sensorChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['10:00', '10:10', '10:20', '10:30', '10:40'],
      datasets: [{
        label: 'Temperature (°C)',
        data: [24, 25.2, 26, 27.1, 26.4],
        backgroundColor: 'rgba(0, 255, 229, 0.2)',
        borderColor: '#00ffe5',
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      scales: {
        x: { ticks: { color: '#ccc' } },
        y: { ticks: { color: '#ccc' } }
      },
      plugins: {
        legend: { labels: { color: '#ccc' } }
      }
    }
  });
}
